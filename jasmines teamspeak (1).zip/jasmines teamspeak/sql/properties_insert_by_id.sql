insert into :tablename: ( server_id, id, ident, value) 
 values( :server_id:, :id:, :ident*:, :value*:)
 [[[,( :server_id:, :id:, :ident*:, :value*:)]]]